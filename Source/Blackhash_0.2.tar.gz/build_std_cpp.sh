g++ -static -std=c++11 -Wall -Wextra -o bh main_std_cpp.cpp  /usr/lib/libcryptopp.a
g++ -g -ggdb -std=c++11 -o bh_debug main_std_cpp.cpp /usr/lib/libcryptopp.so
g++ -static -std=c++11 -o test test.cpp
