g++ -static -Wall -Wextra -o bh main.cpp  /usr/lib/libcryptopp.a
g++ -g -ggdb -o bh_debug main.cpp /usr/lib/libcryptopp.so
g++ -static -o test test.cpp
